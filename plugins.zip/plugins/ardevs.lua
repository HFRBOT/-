do

function run(msg, matches)
return [[

🔸 يعمل البوت ع مجموعات السوبر تصل الى 5k 🌐

    🔸تم تطوير البوت وصنعه بواسطة 🔸
                   🔸  صاد و بكر🔸
                      
                      -🔧 DEV 👹: @hmode_rap                 
                      
             🔸    تابع كل ما يخص البوتات ع قناة البوت 👇🔸
                      
                    -🔧 channel 👹: @al_zaeem_tv     

]]
end

return {
description = "Shows bot q", 
usage = "spam Shows bot q",
patterns = {
"^(المطور)$",
},
run = run 
}
end
