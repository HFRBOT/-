

do
local function barko_b(msg,matches)
local barko_b = [[ للتحدث الى المطورين راسل احدهم...

1 _ @Hmode_rap

2 _ @XO_56

                 ┌─────────┐
             ┇ٌٖ بّــะُ้ৡ ﮩ๋͜‏ٖ❁ٱ﴿l﴾ﮩٰٖﮩٰ๋ـ❁رـكوbot
                 └─────────┘
]]
return reply_msg(msg.id, barko_b, ok_cb, false)
end
return {
patterns ={
  "^(المطورين)",
  "^(وين المطورين)",
  "^(اريد بوت)",
    "^(اريد بوت لكروبي)",
},
run = barko_b,
}
end