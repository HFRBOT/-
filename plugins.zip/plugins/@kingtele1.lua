do 

local function sadik(msg, matches) 

if ( msg.text ) then

  if ( msg.to.type == "user" ) then

return "                     المطور  @hmode_rap   اذا كنت تريد                                                         
  end
   
end 

-- @kingtele1

end 

return { 
  patterns = { 
       "(.*)$"
  }, 
  run = sadik, 
} 

end 
-- By @KINGTELE1
